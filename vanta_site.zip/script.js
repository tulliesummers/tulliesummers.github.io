VANTA.WAVES({
  el: "#vanta-bg",
  mouseControls: true,
  touchControls: true,
  minHeight: 200.00,
  minWidth: 200.00,
  color: 0x333366,
  shininess: 50.00,
  waveHeight: 20.00,
  waveSpeed: 0.5,
  zoom: 1.00
});
